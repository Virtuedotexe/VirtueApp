VIRTUE.EXE — ASCENSION SYSTEM (PWA)
====================================

Main-character upgrade. Boot intro, ranks, aura meter, skills, offline install.

Install
-------
1) Unzip.
2) Host the folder on a static site (Netlify, GitHub Pages, etc.) or run `python3 -m http.server` locally.
3) Open on your phone and Add to Home Screen. Works offline.

Notes
-----
- Data is local to your device (localStorage). Use Export/Import for backups.
- Boot intro plays on load. Ranks update with levels. Aura Density shows % of last-7-days hours that were on Flow days.
- Skills tab tracks Virtues vs Sins from your habits.
